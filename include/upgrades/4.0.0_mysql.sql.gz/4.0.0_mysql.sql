USE alienvault;

REPLACE INTO config (conf, value) VALUES ('last_update', '2012-06-28');
REPLACE INTO config (conf, value) VALUES ('ossim_schema_version', '4.0.0');
-- NOTHING BELOW THIS LINE / NADA DEBAJO DE ESTA LINEA
